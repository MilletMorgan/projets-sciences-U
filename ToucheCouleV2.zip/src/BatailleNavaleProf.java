import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class BatailleNavale {

	public static void affichage(char[][] grille) {
		
		char[] lstAlpha = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		for (int i=0; i < grille.length; i++) {
			System.out.print("\t|   " + lstAlpha[i]);
		}
		System.out.println("\t|");
		int numLigne = 1;
		for (int i = 0; i < grille[0].length; i++ ) {
			for (int j = 0; j < grille.length; j++) {
				System.out.print("--------");				
			}
			System.out.println("---------");
			System.out.print(numLigne);
			System.out.print("\t");
			numLigne +=1;
			for (int j = 0; j < grille[0].length; j++) {
				System.out.print("|   ");
				System.out.print(grille[j][i] + "\t");
			}
			System.out.println("|");
		}

		for (int i = 0; i < grille.length; i++) {
			System.out.print("--------");				
		}
		System.out.println("---------");
	}
	
	public static void choix(char[][] grille, int nbBateau, int nbMun) {
		List<String> colonne = Arrays.asList("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.print("Coordon�es de la prochaine attaque : ");
		String str = reader.nextLine();
		nbMun -= 1;
		int posx = colonne.indexOf(str.split("")[0]);
		int posy = Integer.parseInt(str.substring(1))-1;
		if (grille[posx][posy] == 'B') {
			grille[posx][posy] = 'X';
			nbBateau -= 1;
		}else {
			grille[posx][posy] = 'O';
		}
		affichage(grille);
		
		if (nbBateau > 0 && nbMun > 0) {
			choix(grille, nbBateau, nbMun);
		}else {
			reader.close();
			finJeu(nbBateau);
		}
		
	}
	
	public static void finJeu(int nbBat) {
		if (nbBat == 0) {
			System.out.println("F�licitation, vous avez gagn�.");
		} else {
			System.out.println("Mission �chou�e. Il reste " + nbBat + " bateaux � fl�t.");
		}
	}
	
	public static void placeBateau(char[][] grille) {
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.print("Choisir le nombre de bateau : ");
		int nbBat = reader.nextInt();
		System.out.print("Choisir le nombre de munition : ");
		int nbMun = reader.nextInt();
		Random rand = new Random();
		int posx, posy;
		int compt = nbBat;
		while (compt > 0) {
			posx = rand.nextInt(grille.length);
			posy = rand.nextInt(grille[0].length);
			if (grille[posx][posy] != 'B') {
				grille[posx][posy] = 'B';
				compt -= 1;
			}
		}
		affichage(grille);
		choix(grille, nbBat, nbMun);
	}
	
	public static void main(String[] args) {
		placeBateau(new char[10][10]);
	}

}
