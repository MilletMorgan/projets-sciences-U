﻿namespace CalcSalaire
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbx_TypeSalarie = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_NbHeures = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_TarifHeure = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_TxHeureSup = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_Fixe = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_CA = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_Salaire = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Calculer = new System.Windows.Forms.Button();
            this.bt_Quitter = new System.Windows.Forms.Button();
            this.gbx_Employe = new System.Windows.Forms.GroupBox();
            this.gbx_Commercial = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbx_Employe.SuspendLayout();
            this.gbx_Commercial.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.gbx_Commercial);
            this.groupBox1.Controls.Add(this.gbx_Employe);
            this.groupBox1.Controls.Add(this.bt_Quitter);
            this.groupBox1.Controls.Add(this.bt_Calculer);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbx_TypeSalarie);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(2, -4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(595, 323);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_Salaire);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(126, 206);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(326, 57);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Résultat";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(109, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Calcul Salaire Hebdomadaire";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(176, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Type salarié";
            // 
            // cbx_TypeSalarie
            // 
            this.cbx_TypeSalarie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_TypeSalarie.FormattingEnabled = true;
            this.cbx_TypeSalarie.Items.AddRange(new object[] {
            "Employé",
            "Commercial"});
            this.cbx_TypeSalarie.Location = new System.Drawing.Point(246, 70);
            this.cbx_TypeSalarie.Name = "cbx_TypeSalarie";
            this.cbx_TypeSalarie.Size = new System.Drawing.Size(121, 21);
            this.cbx_TypeSalarie.TabIndex = 1;
            this.cbx_TypeSalarie.SelectedIndexChanged += new System.EventHandler(this.Cbx_TypeSalarie_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nombre d\'heures";
            // 
            // tb_NbHeures
            // 
            this.tb_NbHeures.Location = new System.Drawing.Point(112, 22);
            this.tb_NbHeures.Name = "tb_NbHeures";
            this.tb_NbHeures.Size = new System.Drawing.Size(100, 20);
            this.tb_NbHeures.TabIndex = 2;
            this.tb_NbHeures.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tb_NbHeures_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tarif Horaire";
            // 
            // tb_TarifHeure
            // 
            this.tb_TarifHeure.Location = new System.Drawing.Point(112, 47);
            this.tb_TarifHeure.Name = "tb_TarifHeure";
            this.tb_TarifHeure.Size = new System.Drawing.Size(100, 20);
            this.tb_TarifHeure.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Taux Heure Sup";
            // 
            // tb_TxHeureSup
            // 
            this.tb_TxHeureSup.Location = new System.Drawing.Point(112, 72);
            this.tb_TxHeureSup.Name = "tb_TxHeureSup";
            this.tb_TxHeureSup.Size = new System.Drawing.Size(100, 20);
            this.tb_TxHeureSup.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Fixe";
            // 
            // tb_Fixe
            // 
            this.tb_Fixe.Location = new System.Drawing.Point(55, 34);
            this.tb_Fixe.Name = "tb_Fixe";
            this.tb_Fixe.Size = new System.Drawing.Size(100, 20);
            this.tb_Fixe.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "CA";
            // 
            // tb_CA
            // 
            this.tb_CA.Location = new System.Drawing.Point(55, 59);
            this.tb_CA.Name = "tb_CA";
            this.tb_CA.Size = new System.Drawing.Size(100, 20);
            this.tb_CA.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Salaire Hébdo";
            // 
            // tb_Salaire
            // 
            this.tb_Salaire.Location = new System.Drawing.Point(109, 19);
            this.tb_Salaire.Name = "tb_Salaire";
            this.tb_Salaire.ReadOnly = true;
            this.tb_Salaire.Size = new System.Drawing.Size(187, 20);
            this.tb_Salaire.TabIndex = 7;
            this.tb_Salaire.TabStop = false;
            this.tb_Salaire.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(428, 228);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "€";
            // 
            // bt_Calculer
            // 
            this.bt_Calculer.Location = new System.Drawing.Point(209, 278);
            this.bt_Calculer.Name = "bt_Calculer";
            this.bt_Calculer.Size = new System.Drawing.Size(75, 23);
            this.bt_Calculer.TabIndex = 7;
            this.bt_Calculer.Text = "&Calculer";
            this.bt_Calculer.UseVisualStyleBackColor = true;
            this.bt_Calculer.Click += new System.EventHandler(this.Bt_Calculer_Click);
            // 
            // bt_Quitter
            // 
            this.bt_Quitter.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bt_Quitter.Location = new System.Drawing.Point(304, 278);
            this.bt_Quitter.Name = "bt_Quitter";
            this.bt_Quitter.Size = new System.Drawing.Size(75, 23);
            this.bt_Quitter.TabIndex = 8;
            this.bt_Quitter.Text = "&Quitter";
            this.bt_Quitter.UseVisualStyleBackColor = true;
            this.bt_Quitter.Click += new System.EventHandler(this.Bt_Quitter_Click);
            // 
            // gbx_Employe
            // 
            this.gbx_Employe.Controls.Add(this.label3);
            this.gbx_Employe.Controls.Add(this.label4);
            this.gbx_Employe.Controls.Add(this.label5);
            this.gbx_Employe.Controls.Add(this.tb_NbHeures);
            this.gbx_Employe.Controls.Add(this.tb_TarifHeure);
            this.gbx_Employe.Controls.Add(this.tb_TxHeureSup);
            this.gbx_Employe.Location = new System.Drawing.Point(32, 97);
            this.gbx_Employe.Name = "gbx_Employe";
            this.gbx_Employe.Size = new System.Drawing.Size(252, 103);
            this.gbx_Employe.TabIndex = 7;
            this.gbx_Employe.TabStop = false;
            this.gbx_Employe.Text = "Infos Employé";
            // 
            // gbx_Commercial
            // 
            this.gbx_Commercial.Controls.Add(this.label6);
            this.gbx_Commercial.Controls.Add(this.label7);
            this.gbx_Commercial.Controls.Add(this.tb_Fixe);
            this.gbx_Commercial.Controls.Add(this.tb_CA);
            this.gbx_Commercial.Location = new System.Drawing.Point(339, 100);
            this.gbx_Commercial.Name = "gbx_Commercial";
            this.gbx_Commercial.Size = new System.Drawing.Size(200, 100);
            this.gbx_Commercial.TabIndex = 8;
            this.gbx_Commercial.TabStop = false;
            this.gbx_Commercial.Text = "infos Commercial";
            // 
            // Form1
            // 
            this.AcceptButton = this.bt_Calculer;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bt_Quitter;
            this.ClientSize = new System.Drawing.Size(602, 321);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Calcul salaire Hebdomadaire";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbx_Employe.ResumeLayout(false);
            this.gbx_Employe.PerformLayout();
            this.gbx_Commercial.ResumeLayout(false);
            this.gbx_Commercial.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_Quitter;
        private System.Windows.Forms.Button bt_Calculer;
        private System.Windows.Forms.TextBox tb_CA;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_Fixe;
        private System.Windows.Forms.TextBox tb_TxHeureSup;
        private System.Windows.Forms.TextBox tb_TarifHeure;
        private System.Windows.Forms.TextBox tb_NbHeures;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_TypeSalarie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tb_Salaire;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gbx_Commercial;
        private System.Windows.Forms.GroupBox gbx_Employe;
    }
}

