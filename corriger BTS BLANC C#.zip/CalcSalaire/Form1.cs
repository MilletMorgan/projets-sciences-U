﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcSalaire
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Bt_Calculer_Click(object sender, EventArgs e)
        {
            //1- Récupérer les données saisies
            //2- Convertir / vérifier les données
            //3- Calculer le salaire selon la formule

            if(cbx_TypeSalarie.Text == "Commercial")
            {
                double fixe, ca;
                if(Double.TryParse(tb_Fixe.Text, out fixe) 
                    && Double.TryParse(tb_CA.Text, out ca))
                {
                    tb_Salaire.Text = (fixe + (ca / 100)).ToString();
                }
                else
                {
                    tb_Salaire.Text = "Données erronées ou manquantes";
                }
            }
            else//    AUTO => EMPLOYE
            {
                int nbHeures;
                double tarifH, txHS, salaire;

                if (int.TryParse(tb_NbHeures.Text, out nbHeures)
                    && Double.TryParse(tb_TarifHeure.Text, out tarifH)
                    && Double.TryParse(tb_TxHeureSup.Text, out txHS)
                    )
                {
                    salaire = nbHeures * tarifH;
                    if (nbHeures > 35)
                    {
                        salaire += (nbHeures - 35) * (tarifH * txHS/100) ;
                    }

                    tb_Salaire.Text = salaire.ToString();
                }
                else
                {
                    tb_Salaire.Text = "Données erronées ou manquantes";
                }

            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbx_TypeSalarie.SelectedIndex = 0;

        }

        private void Bt_Quitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Cbx_TypeSalarie_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbx_TypeSalarie.Text == "Commercial")
            {
                gbx_Commercial.Enabled = true;
                gbx_Employe.Enabled = false;
            }
            else
            {
                gbx_Commercial.Enabled = false;
                gbx_Employe.Enabled = true;            
            }
        }

        private void Tb_NbHeures_KeyPress(object sender, KeyPressEventArgs touche)
        {
            if((touche.KeyChar < '0' || touche.KeyChar > '9' || tb_NbHeures.Text.Length > 2) && touche.KeyChar != (char)Keys.Back )
            {
                touche.Handled = true;
            }
        }
    }
}
